// Design a small web page that will allow you to board passengers onto a small aircraft.

// PuffinAir wants you to complete a web site that will facilitate the boarding of passengers at the terminal gate. 
// Another developer has produced an HTML, a CSS, and a empty JS file for you to apply your JavaScript and OOP skills upon.

// There are already coded div’s that represent seat locations, 
// and input elements for the passengers’ name, seat assignment and meal preference. 
// There is also a button to board the passenger.

// Using JS, jQuery, arrays, and objects, add code to the JS file such that:

// When a passenger is boarded by clicking the board button, 
// their name should be placed in the seat area indicating that the seat is occupied.
// When the mouse hovers over a seat that is occupied, the passenger’s meal choice should be displayed.
// If the agent attempts to assign a passenger to a seat that’s already occupied,
//  an alert should be raised with a message indicating that the seat is occupied, and the passenger cannot be boarded.
 

// Download and uncompress the files q2.html, q2.css, and q2.js.
// Make modifications to q2.js.
// Zip and upload: q2.html, q2.css, and q2.js.
const seats = []

$( () => {
    const htmlSeats = $(".seat")
    for (let target of htmlSeats) {
        let seat = new Seat(target.id)
        seats.push(seat)
    }
    let plane = new Airplane(seats)
    $('#board').on ("click", () => {
        let passName = $("#passName").val()
        let passSeat = $("#passSeat").val()
        let passMeal = $("#passMeal").val()

        for (let seat of plane.seats){
            if (seat.number == passSeat) {
                if (seat.isEmpty){
                    const passenger = new Passenger(passName, passSeat, passMeal)
                    plane.loadPassenger(passenger);
                    let seatString = "#" + passenger.seat
                    let withName = ($(seatString).val()) + ": " + passenger.name
                    $(seatString).text(withName) 
                }else {
                    alert("Seat is taken")
                }
            }
        }
    
        
    });
    $('#1A').hover($('#1A').text(($('#1A').text()) + " " + "VEGE"), )
    
   
        /* Todo: 
            1. Use values from input fields to create objects associated with indicated seat positions
            (You can assume that the data is valid - that is, there is no need to perform data validation).
            2. Display the passenger's Name in the appropriate seat location.
            3. When the mouse hovers over a seat where a passenger is assigned, their meal choice should appear.
            4. Do not let a passenger board to a seat that's already occupied.
        */
    });